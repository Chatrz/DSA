#include <stdio.h>

struct Pack {
    int key;
    int size;
};

struct Pack create_Pack(int key, int size) {
    struct Pack pack;
    pack.key = key;
    pack.size = size;
    return pack;
}

static int head = 0;
static int tail = 0;

int main() {
    int lines, first, second;
    struct Pack packs[100000];
    char command;
    scanf("%d",&lines);
    for (int i = 0; i < lines; ++i) {
        scanf(" %c",&command);
        if (command == '+') {
            scanf(" %d %d", &first,&second);
            packs[tail] = create_Pack(first,second);
            tail++;
        }else if (command == '-') {
            scanf(" %d",&first);
            while (first>0) {
                if (packs[head].size > first) {
                    packs[head].size -= first;
                    first = 0;
                }
                else {
                    first -= packs[head].size;
                    head++;
                }
            }
        }else {
            if (packs[head].size != 0) printf("%d\n",packs[head].key);
            else printf("empty\n");
        }
    }
    return 0;
}
