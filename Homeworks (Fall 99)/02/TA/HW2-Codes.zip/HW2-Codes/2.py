class Node:
    def __init__(self, pos, left=None, right=None, val=None):
        self.left = left
        self.right = right
        self.val = val
        self.pos = pos

    def __str__(self):
        return str(self.val)


if __name__ == '__main__':
    n = int(input())
    nodes = [Node(i + 1) for i in range(n)]
    root = None
    for index in range(n):
        i, l, r = (int(s) for s in input().split())
        node = nodes[i - 1]
        node.left = nodes[l - 1] if l != -1 else None
        node.right = nodes[r - 1] if r != -1 else None
        if root is None or node.left == root or node.right == root:
            root = node
    counter = 1


    def in_order(node: Node):
        if not node:
            return
        global counter
        in_order(node.left)
        node.val = counter
        counter += 1
        in_order(node.right)


    in_order(root)
    print(' '.join([str(node) for node in nodes]))
