import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        MyLinkedList[] platforms = new MyLinkedList[n];
        for(int i = 0 ; i < n ;i++) {
            platforms[i] = new MyLinkedList();
            platforms[i].insert(new Node(i+1));
        }
        for(int p = 0 ; p < m ; p++){
            int i = scanner.nextInt() - 1;
            int j = scanner.nextInt() - 1;
            MyLinkedList list1 = platforms[i];
            MyLinkedList list2 = platforms[j];
            list2.addAll(list1);
            list1.makeEmpty();
        }
        int d = scanner.nextInt() - 1;
        MyLinkedList platform = platforms[d];
        System.out.print(platform.size);
        Node head = platform.head;
        while (head != null){
            System.out.print(" " + head.val);
            head = head.next;
        }
    }
}

class Node{
    public Node next;
    public int val;

    public Node(int val) {
        this.val = val;
    }
}

class MyLinkedList{
    public Node head = null;
    public Node tail = null;
    public int size = 0;

    public void insert(Node node){
        size++;
        if(head == null){
            head = node;
            tail = node;
            return;
        }
        node.next = head;
        head = node;
    }

    public void addAll(MyLinkedList list){
        if (list.head == null)
            return;
        if (head == null){
            head = list.head;
            tail = list.tail;
            size = list.size;
            return;
        }
        tail.next = list.head;
        tail = list.tail;
        size += list.size;
    }
    public void makeEmpty(){
        head = null;
        tail = null;
    }
}


