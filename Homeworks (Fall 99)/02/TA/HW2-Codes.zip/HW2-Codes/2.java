import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int size = scanner.nextInt();
        Head[] heads = new Head[size];
        for (int i = 0; i < heads.length; i++) {
            heads[i] = new Head();
        }

        for (int i = 0; i < size; i++) {
            int index = scanner.nextInt()-1, leftIndex = scanner.nextInt()-1,rightIndex = scanner.nextInt()-1;

            if (leftIndex == -2) heads[index].setLeftChild(null);
            else heads[index].setLeftChild(heads[leftIndex]);

            if (rightIndex == -2) heads[index].setRightChild(null);
            else heads[index].setRightChild(heads[rightIndex]);

        }

        Head root;
        for (Head head : heads) {
            if (head.getParent() == null) {
                root = head;
                root.indexHeads();
                break;
            }
        }

        for (Head head : heads) {
            System.out.print(head.getKey() + " ");
        }
    }
}
class Head {

    private static int index = 1;
    private Head parent;
    private int key;
    private Head leftChild;
    private Head rightChild;

    public void indexHeads() {
        if (getLeftChild() != null)
            getLeftChild().indexHeads();
        this.setKey(index);
        index++;
        if (getRightChild() != null)
            getRightChild().indexHeads();
    }


    public Head getParent() {
        return parent;
    }

    public void setParent(Head parent) {
        this.parent = parent;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public Head getLeftChild() {
        return leftChild;
    }

    public void setLeftChild(Head leftChild) {
        if (leftChild != null)
            leftChild.setParent(this);
        this.leftChild = leftChild;
    }

    public Head getRightChild() {
        return rightChild;
    }

    public void setRightChild(Head rightChild) {
        if (rightChild != null)
            rightChild.setParent(this);
        this.rightChild = rightChild;
    }
}
