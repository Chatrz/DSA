import java.util.Scanner;
import java.util.Queue;
import java.util.LinkedList;
import java.util.List;

class Node
{
	int value;
	int times;
	
	public Node(int value, int times)
	{
		this.value = value;
		this.times = times;
	}
}

public class SuperQueue
{
	private static final Queue<Node> queue = new LinkedList<>();
	private static final List<Integer> data = new LinkedList<>();
	
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		
		int q = scanner.nextInt();
		scanner.nextLine();
		
		for (int i = 0; i < q; i++)
		{
			String input = scanner.next();
			char firstChar = input.charAt(0);
			
			switch (firstChar)
			{
				case '+':
					int value = scanner.nextInt();
					int times = scanner.nextInt();
					queue.offer(new Node(value, times));
					
					break;
				case '-':
					int times1 = scanner.nextInt();
					
					while (true)
					{
						Node peekNode = queue.peek();
						
						if (peekNode != null && times1 - peekNode.times >= 0)
						{
							times1 -= peekNode.times;
							queue.poll();
						}
						else
							break;
					}
					
					if (queue.peek() != null)
						queue.peek().times -= times1;
					break;
				case '?':
					if (queue.peek() != null)
						data.add(queue.peek().value);
					else
						data.add(null);
					break;
			}
		}
		
		data.forEach((integer) ->
		{
			if (integer != null)
				System.out.println(integer);
			else
				System.out.println("empty");
		});
	}
}
