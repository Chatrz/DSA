from collections import deque


def get_funcs(queue):
    def push_t(arg):
        queue.append(arg)

    def pop(arg):
        x = arg[0]
        while x != 0:
            if x >= queue[0][1]:
                y = queue.popleft()
                x -= y[1]
            else:
                queue[0][1] -= x
                x = 0

    def top(arg):
        print(queue[0][0] if queue else 'empty')

    return {
        '+':push_t,
        '-':pop,
        '?':top
    }

if __name__ == "__main__":
    queue = deque()
    funcs = get_funcs(queue)
    q = int(input())
    for _ in range(q):
        inp = [int(i) if i.isdigit() else i for i in input().split()]
        fun = funcs[inp[0]]
        fun(inp[1:])

