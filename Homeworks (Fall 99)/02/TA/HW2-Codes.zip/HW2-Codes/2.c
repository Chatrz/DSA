#include <stdio.h>
#include "stdlib.h"

typedef struct {
    int index;
    struct node* left;
    struct node* right;
} node;

node * nodeConstruct(int i){
    node *newNode = malloc(sizeof(node));
    if (newNode == NULL){
        return NULL;
    }
    newNode ->index = i;
    newNode ->left = newNode ->right = NULL;
    return newNode;
}

int tmp;
void printInorder(node* node , int arr[] )
{
    if (node == NULL) {

        return;
    }
    printInorder(node->left, arr );
    arr[(node->index) -1 ] = ++tmp;
    printInorder(node->right , arr );

}

int main() {
    int n;// number of roots
    int i, l, r;
    scanf("%d", &n);
    node* array[n];
    int *roots = malloc(n*sizeof(int));
    for (int m = 0; m <n ; ++m) {
        roots[m] = 0;
    }
    long long sumOfRoots = ( 1LL * n * (n+1) )/2;
    for (int j = 0; j <n ; ++j) {
        array[j] = nodeConstruct(j+1);
    }
    for (int ii = 0; ii <n ; ++ii) {
        scanf("%d %d %d", &i , &l , &r);
        node *foo = array[i-1];
        if (l != -1){
            foo ->left = array[l-1];
            sumOfRoots -= l;
        }
        if ( r != -1){
            foo ->right = array[r-1];
            sumOfRoots -= r;
        }
        }
    printInorder(array[sumOfRoots-1], roots );
    for (int k = 0; k <n ; k++) {
        printf("%d " , roots[k]);
    }

    return 0;
}
