class Node:
    def __init__(self ,val ,nextt = None):
        self.val = val
        self.nextt = nextt

class LinkedList:
    def __init__(self , head):
        self.head , self.tail , self.size = head , head ,  1

    def insert(self , node :Node):
        if not head:
            self.head , self.tail ,self.size = node , node , 1
            return
        node.nextt = self.head
        self.head = node
        self.size += 1

    def insert_all(self , collec ):
        if collec.size == 0:
            return
        if self.size == 0:
            self.head , self.tail = collec.head , collec.tail
            self.size = collec.size
        else:
            self.tail.nextt = collec.head
            self.tail = collec.tail
            self.size += collec.size
        collec.head , collec.tail = None , None
        collec.size = 0

    def get_vals(self):
        beg = self.head
        while beg:
            yield beg.val
            beg = beg.nextt

if __name__ == "__main__":
    n , m = (int(s) for s in input().split())
    platforms = [LinkedList(Node(i+1)) for i in range(n)]
    for _ in range(m):
        i , j = (int(s) for s in input().split())
        platforms[j-1].insert_all(platforms[i-1])
    d = int(input())
    print(f'{platforms[d-1].size} ' + ' '.join([str(i) for i in platforms[d-1].get_vals()]))
